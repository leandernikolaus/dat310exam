contacts = new Array();
// TODO: Remove these. Instead use getEntries()
contacts.push(new Entry("Don John", "12-322-622", "don.john@ymail.com"));
contacts.push(new Entry("Elizabeth Westland", "66-112-312", "e47wl@outlook.com"));
contacts.push(new Entry("John Smith", "12-345-678", "john.smith@gmail.com"));
contacts.push(new Entry("Kevin Magnussen", "+31 997-11-21", "kevinrulez@noemail.com"));


// TODO: Load entries from backend and display.
function getEntries(){

}

// TODO: Send updated entries to backend.
function setEntries(){

}