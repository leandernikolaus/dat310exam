todos = new Array();
todos.push(new Entry("Cleaning", "16/05/2019", "home", "clean living room; clean kitchen"));
// TODO: add two more entries to todos array with categories work and other