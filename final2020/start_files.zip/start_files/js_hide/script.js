function hide(){
    // TODO: Hide the buttons with class "number" and the paragraph with id "padinstructions".
    //  Make sure you only hide these elements.
    //  Elements should be hidden but still take up space.
}

function show(){
    // TODO: Show the buttons with class "number" and the paragraph with id "padinstructions".
}