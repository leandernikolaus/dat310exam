async function role(){
    // remove old content in result div.
    // retrieve a random number from route /random. 
    // while doing this, display the loading symbol, by adding class "loading" to result div.
    // add the resutling number as content to the div.
    // make sure, at most one call is executed at a time
}