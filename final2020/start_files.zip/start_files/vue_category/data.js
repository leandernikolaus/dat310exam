let datalist = [
    { text: "First item", 
      flagged: false,
      done: false
    },
    { text: "Second item", 
      flagged: false,
      done: false
    },
    { text: "Urgent item", 
      flagged: true,
      done: false
    },
    { text: "Done item", 
      flagged: false,
      done: true
    },
    { text: "No longer urgent", 
      flagged: true,
      done: true
    }
]